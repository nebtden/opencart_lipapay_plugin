<?php
// Text
$_['text_title'] = 'LipaPay';